# CS122_9301_Team1


## Description
This project contains major requirements for our CS 122 Computer Programming 2 class.

1. We are tasked to design and build a Fraction class in which several arithmetic operations can be performed to the objects of the Fraction class.

2. We are tasked to design and build a text-based curriculum checklist for the Computer Science program of Saint Louis Univeristy

## Github Repository

[https://github.com/saintramon/fraction-arithemetic-operations](https://github.com/saintramon/fraction-arithemetic-operations)

## Authors and acknowledgment
Programmers:

1. Jasmin, Ramon Emmiel
2. Domingo, Diamond Darrel
3. Rabang, Gebreyl Isaac
4. Baltazar, Rudyard Lans
5. Urbiztondo, Karl Jasper
6. Bumanglag, AU

## License
For Academic Purposes only.

## Project status
The project is now currently doing the Curriculum Checklist Text-Based System


